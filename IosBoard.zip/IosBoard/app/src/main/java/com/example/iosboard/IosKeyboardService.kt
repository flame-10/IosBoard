package com.example.iosboard

import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.SystemClock
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager

class IosKeyboardService : InputMethodService(), IosKeyboardView.Listener {

    private var kv: IosKeyboardView? = null
    private var lastSpace = 0L
    private var capSentences = false

    override fun onCreateInputView(): View {
        val v = IosKeyboardView(this)
        v.listener = this
        kv = v
        return v
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val isNumeric = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
        kv?.setMode(if (isNumeric) IosKeyboardView.Mode.NUMBERS else IosKeyboardView.Mode.LETTERS)
        capSentences = cls == InputType.TYPE_CLASS_TEXT &&
            (info.inputType and InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) != 0
        updateAutoCap()
    }

    private fun updateAutoCap() {
        if (!capSentences) return
        val before = currentInputConnection?.getTextBeforeCursor(3, 0)?.toString() ?: ""
        val on = before.isEmpty() || before.endsWith(". ") || before.endsWith("? ") ||
            before.endsWith("! ") || before.endsWith("\n")
        kv?.setShift(if (on) 1 else 0)
    }

    override fun onText(text: String) {
        currentInputConnection?.commitText(text, 1)
    }

    override fun onDelete() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        updateAutoCap()
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        if (now - lastSpace < 400) {
            val b = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
            if (b.length == 2 && b[1] == ' ' && b[0].isLetterOrDigit()) {
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                lastSpace = 0
                updateAutoCap()
                return
            }
        }
        ic.commitText(" ", 1)
        lastSpace = now
        updateAutoCap()
    }

    override fun onReturn() {
        val info = currentInputEditorInfo
        val action = info?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        val noEnterAction = (info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            sendDefaultEditorAction(true)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        updateAutoCap()
    }

    override fun onGlobe() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (Build.VERSION.SDK_INT >= 28) {
            if (!switchToNextInputMethod(false)) imm.showInputMethodPicker()
        } else {
            imm.showInputMethodPicker()
        }
    }
}
