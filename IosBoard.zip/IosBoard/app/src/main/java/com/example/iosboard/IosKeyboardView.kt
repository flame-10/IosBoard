package com.example.iosboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View

/** iPhone-style keyboard drawn fully on a Canvas. */
class IosKeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onText(text: String)
        fun onDelete()
        fun onSpace()
        fun onReturn()
        fun onGlobe()
    }

    enum class Kind { LETTER, SHIFT, DELETE, MODE, MODE2, GLOBE, SPACE, RETURN, SPACER }
    enum class Mode { LETTERS, NUMBERS, SYMBOLS }

    private class Key(val label: String, val kind: Kind, val weight: Float) {
        val cell = RectF()   // touch area
        val rect = RectF()   // drawn area
    }

    var listener: Listener? = null

    private var mode = Mode.LETTERS
    private var shift = 0              // 0 off, 1 on, 2 caps lock
    private var lastShiftTap = 0L
    private var rows: List<List<Key>> = build(Mode.LETTERS)
    private var pressedKey: Key? = null

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private val barH = dp(40f)
    private val topPad = dp(6f)
    private val keyH = dp(46f)
    private val rowGap = dp(10f)
    private val sidePad = dp(3f)
    private val keyInset = dp(3f)
    private val bottomPad = dp(14f)
    private val radius = dp(5.5f)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1.8f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val tmp = RectF()
    private val path = Path()

    private val handler = Handler(Looper.getMainLooper())
    private val repeatDelete = object : Runnable {
        override fun run() {
            listener?.onDelete()
            handler.postDelayed(this, 55)
        }
    }
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // ---------- layouts ----------
    private fun chars(s: String, w: Float = 1f) = s.map { Key(it.toString(), Kind.LETTER, w) }
    private fun spacer(w: Float) = Key("", Kind.SPACER, w)

    private fun build(m: Mode): List<List<Key>> {
        val bottom = listOf(
            Key(if (m == Mode.LETTERS) "123" else "ABC", Kind.MODE, 1.4f),
            Key("globe", Kind.GLOBE, 1.2f),
            Key("space", Kind.SPACE, 5f),
            Key("return", Kind.RETURN, 2.4f)
        )
        return when (m) {
            Mode.LETTERS -> listOf(
                chars("qwertyuiop"),
                listOf(spacer(0.5f)) + chars("asdfghjkl") + listOf(spacer(0.5f)),
                listOf(Key("shift", Kind.SHIFT, 1.25f), spacer(0.25f)) + chars("zxcvbnm") +
                    listOf(spacer(0.25f), Key("del", Kind.DELETE, 1.25f)),
                bottom
            )
            Mode.NUMBERS -> listOf(
                chars("1234567890"),
                chars("-/:;()$&@\""),
                listOf(Key("#+=", Kind.MODE2, 1.4f), spacer(0.15f)) + chars(".,?!'", 1.38f) +
                    listOf(spacer(0.15f), Key("del", Kind.DELETE, 1.4f)),
                bottom
            )
            Mode.SYMBOLS -> listOf(
                chars("[]{}#%^*+="),
                chars("_\\|~<>€£¥•"),
                listOf(Key("123", Kind.MODE2, 1.4f), spacer(0.15f)) + chars(".,?!'", 1.38f) +
                    listOf(spacer(0.15f), Key("del", Kind.DELETE, 1.4f)),
                bottom
            )
        }
    }

    // ---------- public api ----------
    fun setMode(m: Mode) {
        mode = m
        rows = build(m)
        layoutKeys()
        invalidate()
    }

    fun setShift(s: Int) {
        shift = s
        invalidate()
    }

    // ---------- measure / layout ----------
    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val h = barH + topPad + 4 * keyH + 3 * rowGap + bottomPad
        setMeasuredDimension(MeasureSpec.getSize(widthSpec), h.toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutKeys()
    }

    private fun layoutKeys() {
        if (width == 0) return
        val usable = width - 2 * sidePad
        rows.forEachIndexed { r, row ->
            val total = row.sumOf { it.weight.toDouble() }.toFloat()
            val unit = usable / total
            var x = sidePad
            val top = barH + topPad + r * (keyH + rowGap)
            for (k in row) {
                val w = k.weight * unit
                k.cell.set(x, top - rowGap / 2, x + w, top + keyH + rowGap / 2)
                k.rect.set(x + keyInset, top, x + w - keyInset, top + keyH)
                x += w
            }
        }
    }

    // ---------- touch ----------
    private fun keyAt(x: Float, y: Float): Key? {
        if (rows.isEmpty() || width == 0) return null
        val firstTop = rows.first().first().cell.top
        if (y < firstTop) return null
        val lastBottom = rows.last().first().cell.bottom
        val yy = minOf(y, lastBottom - 1f)
        val xx = x.coerceIn(0f, width - 1f)
        for (row in rows) {
            for ((i, k) in row.withIndex()) {
                if (k.cell.contains(xx, yy)) {
                    if (k.kind != Kind.SPACER) return k
                    // spacer: snap to nearest real neighbour
                    return when {
                        i == 0 -> row[1]
                        i == row.lastIndex -> row[i - 1]
                        xx < k.cell.centerX() -> row[i - 1]
                        else -> row[i + 1]
                    }
                }
            }
        }
        return null
    }

    private fun press(k: Key?) {
        if (k === pressedKey) return
        handler.removeCallbacks(repeatDelete)
        pressedKey = k
        if (k != null) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            audio.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
            if (k.kind == Kind.DELETE) {
                listener?.onDelete()
                handler.postDelayed(repeatDelete, 400)
            }
        }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> press(keyAt(e.x, e.y))
            MotionEvent.ACTION_UP -> {
                val k = pressedKey
                press(null)
                if (k != null && k.kind != Kind.DELETE) commit(k)
            }
            MotionEvent.ACTION_CANCEL -> press(null)
        }
        return true
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(repeatDelete)
        super.onDetachedFromWindow()
    }

    private fun commit(k: Key) {
        when (k.kind) {
            Kind.LETTER -> {
                listener?.onText(labelOf(k))
                if (shift == 1) { shift = 0; invalidate() }
            }
            Kind.SHIFT -> {
                val now = SystemClock.uptimeMillis()
                shift = when {
                    shift == 2 -> 0
                    shift == 1 && now - lastShiftTap < 350 -> 2
                    shift == 1 -> 0
                    else -> 1
                }
                lastShiftTap = now
                invalidate()
            }
            Kind.MODE -> setMode(if (mode == Mode.LETTERS) Mode.NUMBERS else Mode.LETTERS)
            Kind.MODE2 -> setMode(if (mode == Mode.NUMBERS) Mode.SYMBOLS else Mode.NUMBERS)
            Kind.GLOBE -> listener?.onGlobe()
            Kind.SPACE -> listener?.onSpace()
            Kind.RETURN -> listener?.onReturn()
            else -> {}
        }
    }

    private fun labelOf(k: Key) =
        if (mode == Mode.LETTERS && shift != 0) k.label.uppercase() else k.label

    // ---------- drawing ----------
    private fun isDark() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    override fun onDraw(c: Canvas) {
        val dark = isDark()
        val bgC = if (dark) 0xFF2A2A2C.toInt() else 0xFFD1D4DB.toInt()
        val letterC = if (dark) 0xFF6B6B6D.toInt() else 0xFFFFFFFF.toInt()
        val specialC = if (dark) 0xFF444446.toInt() else 0xFFABB1BA.toInt()
        val shadowC = if (dark) 0xFF161617.toInt() else 0xFF898A8D.toInt()
        val textC = if (dark) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()

        c.drawColor(bgC)
        textP.color = textC
        line.color = textC

        for (row in rows) for (k in row) {
            if (k.kind == Kind.SPACER) continue
            val pressed = k === pressedKey
            val letterStyle = k.kind == Kind.LETTER || k.kind == Kind.SPACE
            val fc = when {
                k.kind == Kind.SPACE && pressed -> specialC
                letterStyle -> letterC
                pressed -> letterC
                else -> specialC
            }
            tmp.set(k.rect.left, k.rect.top + dp(1f), k.rect.right, k.rect.bottom + dp(1f))
            fill.color = shadowC
            c.drawRoundRect(tmp, radius, radius, fill)
            fill.color = fc
            c.drawRoundRect(k.rect, radius, radius, fill)

            val cx = k.rect.centerX()
            val cy = k.rect.centerY()
            when (k.kind) {
                Kind.LETTER -> if (!pressed) drawText(c, labelOf(k), cx, cy, dp(24f))
                Kind.SPACE -> drawText(c, "space", cx, cy, dp(16f))
                Kind.RETURN, Kind.MODE, Kind.MODE2 -> drawText(c, k.label, cx, cy, dp(16f))
                Kind.SHIFT -> drawShift(c, cx, cy)
                Kind.DELETE -> drawDelete(c, cx, cy)
                Kind.GLOBE -> drawGlobe(c, cx, cy)
                else -> {}
            }
        }

        // key popup balloon
        val pk = pressedKey
        if (pk != null && pk.kind == Kind.LETTER) {
            var l = pk.rect.left - dp(9f)
            var r = pk.rect.right + dp(9f)
            if (l < dp(2f)) { r += dp(2f) - l; l = dp(2f) }
            if (r > width - dp(2f)) { l -= r - (width - dp(2f)); r = width - dp(2f) }
            val t = pk.rect.top - dp(56f)
            val b = pk.rect.bottom
            tmp.set(l, t + dp(1f), r, b + dp(1f))
            fill.color = shadowC
            c.drawRoundRect(tmp, dp(10f), dp(10f), fill)
            tmp.set(l, t, r, b)
            fill.color = letterC
            c.drawRoundRect(tmp, dp(10f), dp(10f), fill)
            drawText(c, labelOf(pk), (l + r) / 2, t + dp(30f), dp(36f))
        }
    }

    private fun drawText(c: Canvas, s: String, cx: Float, cy: Float, size: Float) {
        textP.textSize = size
        val fm = textP.fontMetrics
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2, textP)
    }

    private fun drawShift(c: Canvas, cx: Float, cy: Float) {
        val s = dp(9f)
        val y = cy - dp(1f)
        path.reset()
        path.moveTo(cx, y - s)
        path.lineTo(cx + s, y)
        path.lineTo(cx + s * 0.45f, y)
        path.lineTo(cx + s * 0.45f, y + s * 0.8f)
        path.lineTo(cx - s * 0.45f, y + s * 0.8f)
        path.lineTo(cx - s * 0.45f, y)
        path.lineTo(cx - s, y)
        path.close()
        line.style = if (shift != 0) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
        c.drawPath(path, line)
        if (shift == 2) {
            line.style = Paint.Style.FILL
            c.drawRect(cx - s * 0.45f, y + s * 1.05f, cx + s * 0.45f, y + s * 1.05f + dp(2f), line)
        }
        line.style = Paint.Style.STROKE
    }

    private fun drawDelete(c: Canvas, cx: Float, cy: Float) {
        val s = dp(9f)
        path.reset()
        path.moveTo(cx - s * 1.15f, cy)
        path.lineTo(cx - s * 0.45f, cy - s * 0.8f)
        path.lineTo(cx + s * 1.1f, cy - s * 0.8f)
        path.lineTo(cx + s * 1.1f, cy + s * 0.8f)
        path.lineTo(cx - s * 0.45f, cy + s * 0.8f)
        path.close()
        line.style = Paint.Style.STROKE
        c.drawPath(path, line)
        c.drawLine(cx - s * 0.05f, cy - s * 0.35f, cx + s * 0.65f, cy + s * 0.35f, line)
        c.drawLine(cx - s * 0.05f, cy + s * 0.35f, cx + s * 0.65f, cy - s * 0.35f, line)
    }

    private fun drawGlobe(c: Canvas, cx: Float, cy: Float) {
        val s = dp(9.5f)
        line.style = Paint.Style.STROKE
        line.strokeWidth = dp(1.5f)
        c.drawCircle(cx, cy, s, line)
        tmp.set(cx - s * 0.45f, cy - s, cx + s * 0.45f, cy + s)
        c.drawOval(tmp, line)
        c.drawLine(cx - s, cy, cx + s, cy, line)
        line.strokeWidth = dp(1.8f)
    }
}
